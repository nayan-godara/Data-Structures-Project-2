#include<iostream>
#include"list.h"
#include<stdexcept>

using namespace std;
List::List(){
    try{
    sentinel_head= new Node(true);
    sentinel_tail=new Node(true);
    sentinel_tail->prev=sentinel_head;
    sentinel_head->prev=sentinel_tail;
    sentinel_head->next=sentinel_tail;
    size=0;
    }
    catch(const std::bad_alloc& t){
            throw runtime_error("Out of Memory");



        }
}
List::~List(){
    while(sentinel_head->next!=sentinel_tail){
        this->delete_tail();

    }
    delete sentinel_tail;
    delete sentinel_head;
}
int List:: get_size(){
    return size;
}
void List::insert(int v){
    try{
        Node * newnode= new Node(v,sentinel_tail,sentinel_tail->prev);
        sentinel_tail->prev->next=newnode;
        sentinel_tail->prev=newnode;
        size++;


    }
    catch(const std::bad_alloc& t){
        throw runtime_error("Out of Memory");


    }

}
int List:: delete_tail(){
    if(size==0){
        throw runtime_error("Empty Stack");
    }
    else{
        Node* temp=sentinel_tail->prev;
        sentinel_tail->prev->prev->next=sentinel_tail;
        
        
        sentinel_tail->prev=sentinel_tail->prev->prev;
        int answer=temp->get_value();
        delete temp;
        size--;
        return answer;

        
    }

}
Node* List::get_head(){
    return sentinel_head;
}