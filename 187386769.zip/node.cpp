#include<iostream>
#include"node.h"
#include<stdexcept>
Node::Node(bool sentinel){
    value=-5;
    is_sentinel=true;
    prev=nullptr;
    next=nullptr;
}
Node::Node(int v, Node* nxt, Node* prv){
    is_sentinel=false;
    prev=prv;
    next=nxt;
    value=v;
}
bool Node::is_sentinel_node(){
    bool head_or_tail= is_sentinel;
    return head_or_tail;

}
int Node::get_value(){
    return value;
}