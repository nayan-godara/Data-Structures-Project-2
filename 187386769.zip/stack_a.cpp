#include"stack_a.h"
#include<iostream>
#include<stdexcept>
using namespace std;
Stack_A::Stack_A(){
    size=0;
}
void Stack_A::push(int data){
    if(size==1024){
        throw runtime_error("Stack Full");

    }
    else{
        stk[size]=data;
        size++;
    }
}
int Stack_A::pop(){
    if(size==0){
        throw runtime_error("Empty Stack");


    
    }
    else{
        size--;
        return stk[size];
    }
}
int  Stack_A:: get_element_from_top(int idx){
    if(idx>(size)-1 || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        return stk[size-1-idx];

    }


}
int  Stack_A:: get_element_from_bottom(int idx){
    if(idx>(size-1) || idx<0){
        throw runtime_error("Index out of range");
    }
    else{
        return stk[idx];

    }


}
void Stack_A::print_stack(bool top_or_bottom){
    if(top_or_bottom){
        for(int i=(size-1);i>=0;i--){
            cout<<stk[i]<<"\n";

        }
    }
    else{
        for(int i=0;i<size;i++){
            cout<<stk[i]<<"\n";

        }

    }
}
int Stack_A:: add(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int sum=top +belowtop;
        this->push(sum);
        return sum;
    }
    
}
int Stack_A:: subtract(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int dif=belowtop-top;
        this->push(dif);
        return dif;
    }
    
}
int Stack_A:: multiply(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int pdt=top*belowtop;
        this->push(pdt);
        return pdt;
    }
    
}
int Stack_A:: divide(){
    if(size<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        if(top!=0){
            if(top*belowtop<0){
                if(belowtop%top!=0){
                int div =(belowtop/top)-1;
                this->push(div);
                return div;
                }
                else{
                    int div=(belowtop/top);
                    this->push(div);
                    return div;
                }
            }
            else{
        int div=(belowtop/top);
        this->push(div);
        return div;
            }
        }
        else{
            throw runtime_error("Divide by Zero Error");
        }
    }
    
}
int *Stack_A ::get_stack(){
    int *point=&stk[0];
    return point;


}
int Stack_A:: get_size(){
    return size;
}


