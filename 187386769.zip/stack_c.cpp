#include<iostream>
#include"stack_c.h"
#include"list.h"
#include<stdexcept>

using namespace std;
Stack_C :: Stack_C(){
    stk = new List;
}
Stack_C::~Stack_C(){
    delete stk;
}
void Stack_C::push(int data){
    stk->insert(data);
}
int Stack_C::pop(){
    int top=stk->delete_tail();
    return top;
}
int Stack_C::get_element_from_top(int idx){
    if(idx>((this->get_size())-1)|| idx<0){
        throw runtime_error("Index out of range");

    }
    else{
        Node* head= stk->get_head();
        Node * tail=head->prev;
        Node * current= tail;
        for(int i=0;i<=idx;i++){
            current=current->prev;
        }
        return current->get_value();
    }
}
int Stack_C::get_element_from_bottom(int idx){
    if(idx>((this->get_size())-1)|| idx<0){
        throw runtime_error("Index out of range");

    }
    else{
        Node* head= stk->get_head();
        Node * tail=head->prev;
        Node * current=head;
        for(int i=0;i<=idx;i++){
            current=current->next;
        }
        return current->get_value();
    }
}
void Stack_C::print_stack(bool top_or_bottom){
    if(top_or_bottom){
        Node* head= stk->get_head();
        Node * tail=head->prev;
        Node * current= head;
    while(current->next!=tail){
        cout<<current->next->get_value()<<"\n";
        current=current->next;
    }
    }
    else{
        Node* head= stk->get_head();
        Node * tail=head->prev;
        
    Node * current= tail;
    while(current->prev!=head){
        cout<<current->prev->get_value()<<"\n";
        current=current->prev;
    }
    }
}
int Stack_C::add(){
    if(this->get_size()<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int sum=top +belowtop;
        this->push(sum);
        return sum;
    }
    
}
int Stack_C::subtract(){
    if(this->get_size()<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int dif=belowtop-top;
        this->push(dif);
        return dif;
    }
    
}
int Stack_C::multiply(){
    if(this->get_size()<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        int pdt=top*belowtop;
        this->push(pdt);
        return pdt;
    }
    
}
int Stack_C:: divide(){
    if((stk->get_size())<2){
        throw runtime_error("Not Enough Arguments");


    }
    else{
        int top=this->pop();
        int belowtop=this->pop();
        if(top!=0){
            if(top*belowtop<0){
                if(belowtop%top!=0){
                int div =(belowtop/top)-1;
                this->push(div);
                return div;
                }
                else{
                    int div=(belowtop/top);
                    this->push(div);
                    return div;
                }
            }
            else{
        int div=(belowtop/top);
        this->push(div);
        return div;
            }
        }
        else{
            throw runtime_error("Divide by Zero Error");
        }
    }
    
}
List *Stack_C::get_stack(){
    return stk;


}
int Stack_C::get_size(){
    return stk->get_size();
}


